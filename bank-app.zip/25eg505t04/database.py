import sqlite3

conn = sqlite3.connect("database.db")

conn.execute("""
CREATE TABLE IF NOT EXISTS accounts(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
parent TEXT,
dob TEXT,
aadhaar TEXT,
pan TEXT,
photo TEXT,
signature TEXT
)
""")

print("Database created")

conn.close()