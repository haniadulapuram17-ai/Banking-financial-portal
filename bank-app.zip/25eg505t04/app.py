from flask import Flask, render_template, request, redirect
import sqlite3
import os
app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
accounts=[]


def connect_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/accounts")
def accounts():

    conn = connect_db()
    accounts = conn.execute("SELECT * FROM accounts").fetchall()
    conn.close()

    return render_template("accounts.html", accounts=accounts)


@app.route('/create_account', methods=['GET', 'POST'])
def create_account():

    if request.method == 'POST':

        name = request.form['name']
        parent = request.form['parent_name']
        dob = request.form['dob']
        aadhaar = request.form['aadhaar']
        pan = request.form['pan']

        photo = request.files['photo']
        signature = request.files['signature']

        # Save files
        photo_path = os.path.join(app.config['UPLOAD_FOLDER'], photo.filename)
        signature_path = os.path.join(app.config['UPLOAD_FOLDER'], signature.filename)

        photo.save(photo_path)
        signature.save(signature_path)

        # Save data in database
        conn = connect_db()

        conn.execute("""
        INSERT INTO accounts(name,parent,dob,aadhaar,pan,photo,signature)
        VALUES (?,?,?,?,?,?,?)
        """, (name, parent, dob, aadhaar, pan, photo.filename, signature.filename))

        conn.commit()
        conn.close()

        return redirect('/accounts')

    return render_template("create_account.html")
@app.route("/transfer", methods=["GET","POST"])
def transfer():

    if request.method == "POST":

        from_acc = request.form["from_account"]
        to_acc = request.form["to_account"]
        amount = int(request.form["amount"])

        conn = connect_db()

        # deduct from sender
        conn.execute(
            "UPDATE accounts SET balance = balance - ? WHERE id=?",
            (amount, from_acc)
        )

        # add to receiver
        conn.execute(
            "UPDATE accounts SET balance = balance + ? WHERE id=?",
            (amount, to_acc)
        )

        conn.commit()
        conn.close()

        return redirect("/accounts")

    return render_template("transfer.html")
@app.route("/support")
def support():
    return render_template("support.html")
@app.route("/payments", methods=["GET","POST"])
def payments():

    if request.method == "POST":

        account_id = request.form["account_id"]
        amount = int(request.form["amount"])

        conn = connect_db()

        conn.execute(
            "UPDATE accounts SET balance = balance - ? WHERE id=?",
            (amount, account_id)
        )

        conn.commit()
        conn.close()

        return redirect("/accounts")

    return render_template("payments.html")
@app.route("/login", methods=["GET","POST"])
def login():
    return render_template("login.html")


@app.route("/register", methods=["GET","POST"])
def register():
    return render_template("register.html")


if __name__ == "__main__":
    app.run(debug=True)